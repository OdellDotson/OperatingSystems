Odell Dotson Assigment 1 CS3013: Operating Systems

This program allows the user to input commands and see information about those commands.

If the command is given with the initialization of the program, it will run that command, print information about it, and then this program
will terminate.

If no command is given, this program will act as a shell, receiving commands until it receives the special command "exit", or if it receives 
an empty line input.

Users can also use the special command "cd" to change directories.

Commands with the & argument given after them, the program will run in the background, and allow other inputs from the user.
(Sadly commands run in the background gives iffy statistics.)
(Sadly background processes also must be killed individually.)

The dir directory is included in the zip with this project so that there is a subdirectory to cd into.

