-------------------------------------------------------------------------------
Operating Systems - CS3013 Project 2b
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
Credits
	Odell Dotson
	Jacob Hackett
-------------------------------------------------------------------------------
Project description

This project deals with Loadable Kernal Modules. Two types of system call 
interceptions were used: a straightforward monitoring approach and a more
creative interception. 
-------------------------------------------------------------------------------
Dependencies:

Must be run on Linux 14.04.1 32x.
-------------------------------------------------------------------------------
Documentation
Part 1 files are in part1 folder. Part 2 files are in part2. Files are self
documented and names are obvious.
-------------------------------------------------------------------------------
Installation instructions

Use Makefiles provides
-------------------------------------------------------------------------------